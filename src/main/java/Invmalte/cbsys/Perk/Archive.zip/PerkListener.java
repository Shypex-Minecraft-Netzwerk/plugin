package Invmalte.cbsys.Perk;

import Invmalte.cbsys.GUI.Gui;
import Invmalte.cbsys.CBSys;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.UUID;

public class PerkListener implements Listener {
    private final Gui gui;
    private final HashSet<UUID> jumpPerks = new HashSet<>();
    private final HashSet<UUID> staerkePerks = new HashSet<>();
    private final HashSet<UUID> abbauPerks = new HashSet<>();
    private final CBSys plugin;
    private File perksFile;
    private FileConfiguration perksConfig;
    private Economy economy;

    public PerkListener(Gui gui, Economy economy, CBSys plugin) {
        this.gui = gui;
        this.economy = economy;
        this.plugin = plugin;

        // Datei vorbereiten
        setupPerksFile();

        // Perks laden
        loadPerks();
    }

    private void setupPerksFile() {
        perksFile = new File(plugin.getDataFolder(), "perks.yml");
        if (!perksFile.exists()) {
            try {
                perksFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        perksConfig = YamlConfiguration.loadConfiguration(perksFile);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getView().getTitle().equalsIgnoreCase(ChatColor.BLUE + "" + ChatColor.BOLD + "Perks")) {
            event.setCancelled(true);

            ItemStack item = event.getCurrentItem();
            if (item == null || !item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) return;

            Player player = (Player) event.getWhoClicked();
            UUID playerUUID = player.getUniqueId();
            String itemName = item.getItemMeta().getDisplayName();

            if (itemName.equalsIgnoreCase("§9§lJump Boost")) {
                if (!jumpPerks.contains(playerUUID) && !buyPerk(player, 100_000)) return;
                jumpPerks.add(playerUUID);
                savePerks();
                toggleEffect(player, PotionEffectType.JUMP_BOOST, CBSys.PREFIX + "Jump Boost §aaktiviert", CBSys.PREFIX + "Jump Boost §cdeaktiviert", item);
            } else if (itemName.equalsIgnoreCase("§9§lStärke Perk")) {
                if (!staerkePerks.contains(playerUUID) && !buyPerk(player, 300_000)) return;
                staerkePerks.add(playerUUID);
                savePerks();
                toggleEffect(player, PotionEffectType.STRENGTH, CBSys.PREFIX + "Stärke Boost §aaktiviert", CBSys.PREFIX + "Stärke Boost §cdeaktiviert", item);
            } else if (itemName.equalsIgnoreCase("§9§lAbbau Perk")) {
                if (!abbauPerks.contains(playerUUID) && !buyPerk(player, 300_000)) return;
                abbauPerks.add(playerUUID);
                savePerks();
                toggleEffect(player, PotionEffectType.HASTE, CBSys.PREFIX + "Abbau Boost §aaktiviert", CBSys.PREFIX + "Abbau Boost §cdeaktiviert", item);
            } else if (itemName.equalsIgnoreCase("zurück")) {
                gui.GUI(player);
            }
        }
    }

    private boolean buyPerk(Player player, double preis) {
        double balance = economy.getBalance(player.getName());
        if (balance >= preis) {
            economy.withdrawPlayer(player.getName(), preis);
            player.sendMessage(CBSys.PREFIX + "§aDu hast das Perk gekauft!");
            return true;
        } else {
            player.sendMessage(CBSys.PREFIX + "§cNicht genug Geld! Du brauchst §e" + formatNumber(preis) + "€§7.");
            return false;
        }
    }

    private void toggleEffect(Player player, PotionEffectType effect, String enableMSG, String disableMSG, ItemStack item) {
        if (player.hasPotionEffect(effect)) {
            if (item.getItemMeta().hasEnchants()) {
                item.removeEnchantment(Enchantment.FLAME);
            }
            player.removePotionEffect(effect);
            player.sendMessage(disableMSG);
        } else {
            item.addUnsafeEnchantment(Enchantment.FLAME, 1);
            player.addPotionEffect(new PotionEffect(effect, Integer.MAX_VALUE, 1));
            player.sendMessage(enableMSG);
        }
    }

    private void savePerks() {
        for (UUID uuid : jumpPerks) {
            perksConfig.set("perks.jumpboost." + uuid.toString(), true);
        }
        for (UUID uuid : staerkePerks) {
            perksConfig.set("perks.staerkeboost." + uuid.toString(), true);
        }
        for (UUID uuid : abbauPerks) {
            perksConfig.set("perks.abbauboost." + uuid.toString(), true);
        }
        try {
            perksConfig.save(perksFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadPerks() {
        if (perksConfig.contains("perks.jumpboost")) {
            for (String uuid : perksConfig.getConfigurationSection("perks.jumpboost").getKeys(false)) {
                if (perksConfig.getBoolean("perks.jumpboost." + uuid)) {
                    jumpPerks.add(UUID.fromString(uuid));
                }
            }
        }
        if (perksConfig.contains("perks.staerkeboost")) {
            for (String uuid : perksConfig.getConfigurationSection("perks.staerkeboost").getKeys(false)) {
                if (perksConfig.getBoolean("perks.staerkeboost." + uuid)) {
                    staerkePerks.add(UUID.fromString(uuid));
                }
            }
        }
        if (perksConfig.contains("perks.abbauboost")) {
            for (String uuid : perksConfig.getConfigurationSection("perks.abbauboost").getKeys(false)) {
                if (perksConfig.getBoolean("perks.abbauboost." + uuid)) {
                    abbauPerks.add(UUID.fromString(uuid));
                }
            }
        }
    }

    public static String formatNumber(double number) {
        if (number >= 1_000_000_000) {
            return number / 1_000_000_000 + "B";
        } else if (number >= 1_000_000) {
            return number / 1_000_000 + "M";
        } else if (number >= 1_000) {
            return number / 1_000 + "K";
        }
        return String.valueOf(number);
    }
}
