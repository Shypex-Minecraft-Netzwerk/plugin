package Invmalte.cbsys.Perk;

import Invmalte.cbsys.GUI.Gui;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;

public class PerkGui implements CommandExecutor {
    private final Gui gui;
    public PerkGui(Gui gui) {
        this.gui = gui;
    }
    public void Gui(Player player) {
        Inventory inventory = Bukkit.createInventory(null, 54, "§9§lPerks");

        ItemStack jump = new ItemStack(Material.RABBIT_FOOT);
        ItemMeta jumpMeta = jump.getItemMeta();
        jumpMeta.setDisplayName("§9§lJump Boost");
        jumpMeta.setLore(Arrays.asList("§7Links-/Rechtsklick zum De-/Aktivieren"));
        jump.setItemMeta(jumpMeta);

        ItemStack Stärke = new ItemStack(Material.IRON_SWORD);
        ItemMeta StärkeMeta = Stärke.getItemMeta();
        StärkeMeta.setDisplayName("§9§lStärke Perk");
        StärkeMeta.setLore(Arrays.asList("§7Links-/Rechtsklick zum De-/Aktivieren"));
        Stärke.setItemMeta(StärkeMeta);

        ItemStack AbbauPerk = new ItemStack(Material.IRON_PICKAXE);
        ItemMeta AbbauPerkMeta = AbbauPerk.getItemMeta();
        AbbauPerkMeta.setDisplayName("§9§lAbbau Perk");
        AbbauPerkMeta.setLore(Arrays.asList("§7Links-/Rechtsklick zum De-/Aktivieren"));
        AbbauPerk.setItemMeta(AbbauPerkMeta);

        inventory.setItem(11, jump);
        inventory.setItem(13, Stärke);
        inventory.setItem(15, AbbauPerk);

        /*
           (gold)
           2.2 Nachtsicht Helm
           3.2 Eile Spitzhacke
           4.2 Stärke Schwert
           5.2 Speed Schuhe

           2.4 N Lvl1
           3.4 E Lvl1
           3.5 E Lvl2
           4.4 S Lvl1
           4.5 S Lvl2
           5.4 S Lvl1
           5.5 S Lvl2
         */
        gui.Halter();

        player.openInventory(inventory);

        }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        Player player = (Player) sender;
        Gui(player);
        return true;
    }
}
